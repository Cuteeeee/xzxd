$(document).ready(function(){
	var bannerText = '<div class="wrapper1 banner-text wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">\
    				  <p class="white font-30">依托互联网+金融的大潮下，加入我们</p>\
    				  </div><div class="wrapper1 banner-text wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.9s">\
					  <p class="white font-20" style="margin-top:10px;">&nbsp;开启财富之轮，生生不息。</p>\
					  </div>';
//    $(".head").append(bannerText);
    $(".muser-banner").removeClass("muser-banner").addClass("abut-banner");
//    new WOW().init();
});
